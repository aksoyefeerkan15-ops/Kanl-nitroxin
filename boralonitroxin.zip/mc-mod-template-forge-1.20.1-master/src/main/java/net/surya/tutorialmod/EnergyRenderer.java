package net.surya.tutorialmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

@Mod.EventBusSubscriber(
        modid = TutorialMod.MOD_ID,
        value = net.minecraftforge.api.distmarker.Dist.CLIENT
)
public class EnergyRenderer {

    @SubscribeEvent
    public static void renderEnergy(RenderLevelStageEvent event) {

        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        Player player = minecraft.player;

        if (player == null) {
            return;
        }

        // Kanlı Nitroxin gücü aktif mi?
        if (!player.hasEffect(net.minecraft.world.effect.MobEffects.DAMAGE_BOOST)) {
            return;
        }

        PoseStack poseStack = event.getPoseStack();

        MultiBufferSource.BufferSource buffer =
                minecraft.renderBuffers().bufferSource();

        VertexConsumer vertexConsumer =
                buffer.getBuffer(RenderType.lines());

        double cameraX = minecraft.gameRenderer
                .getMainCamera().getPosition().x;

        double cameraY = minecraft.gameRenderer
                .getMainCamera().getPosition().y;

        double cameraZ = minecraft.gameRenderer
                .getMainCamera().getPosition().z;

        Matrix4f matrix = poseStack.last().pose();

        float x = (float) (player.getX() - cameraX);
        float y = (float) (player.getY() - cameraY);
        float z = (float) (player.getZ() - cameraZ);

        // Kırmızı enerji çizgileri
        for (int i = 0; i < 16; i++) {

            double angle = (Math.PI * 2.0 / 16.0) * i;

            float x1 = x + (float) Math.cos(angle) * 0.35F;
            float y1 = y + 0.2F;
            float z1 = z + (float) Math.sin(angle) * 0.35F;

            float x2 = x + (float) Math.cos(angle) * 1.0F;
            float y2 = y + 0.8F;
            float z2 = z + (float) Math.sin(angle) * 1.0F;

            vertexConsumer
                    .vertex(matrix, x1, y1, z1)
                    .color(1.0F, 0.0F, 0.0F, 1.0F)
                    .normal(0.0F, 1.0F, 0.0F)
                    .endVertex();

            vertexConsumer
                    .vertex(matrix, x2, y2, z2)
                    .color(1.0F, 0.0F, 0.0F, 1.0F)
                    .normal(0.0F, 1.0F, 0.0F)
                    .endVertex();
        }

        buffer.endBatch(RenderType.lines());
    }
}