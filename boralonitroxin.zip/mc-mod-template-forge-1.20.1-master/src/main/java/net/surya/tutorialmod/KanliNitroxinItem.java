package net.surya.tutorialmod;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

public class KanliNitroxinItem extends Item {

    public KanliNitroxinItem() {
        super(new Item.Properties().stacksTo(1));
    }

    @Override
    public ItemStack finishUsingItem(
            ItemStack stack,
            Level level,
            LivingEntity entity
    ) {
        if (!level.isClientSide) {

            // Kanlı Nitroxin gücü 5 dakika aktif
            entity.addEffect(new MobEffectInstance(
                    MobEffects.DAMAGE_BOOST,
                    20 * 60 * 5,
                    1,
                    false,
                    false,
                    false
            ));
        }

        return super.finishUsingItem(stack, level, entity);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 32;
    }
}