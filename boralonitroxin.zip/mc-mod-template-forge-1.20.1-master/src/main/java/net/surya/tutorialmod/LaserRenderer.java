package net.surya.tutorialmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import net.minecraft.world.phys.Vec3;

@Mod.EventBusSubscriber(
        modid = TutorialMod.MOD_ID,
        value = net.minecraftforge.api.distmarker.Dist.CLIENT
)
public class LaserRenderer {

    @SubscribeEvent
    public static void renderLaser(RenderLevelStageEvent event) {

        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        Player player = minecraft.player;

        if (player == null) {
            return;
        }

        // Kanlı Nitroxin gücü aktif değilse lazer yok
        if (!player.hasEffect(net.minecraft.world.effect.MobEffects.DAMAGE_BOOST)) {
            return;
        }

        // L basılı değilse lazer yok
        if (!NitroxinKey.LASER_KEY.isDown()) {
            return;
        }

        PoseStack poseStack = event.getPoseStack();

        MultiBufferSource.BufferSource buffer =
                minecraft.renderBuffers().bufferSource();

        VertexConsumer vertexConsumer =
                buffer.getBuffer(RenderType.lines());

        Vec3 cameraPos =
                minecraft.gameRenderer.getMainCamera().getPosition();

        // Lazerin başlangıç noktası: gözler
        Vec3 start = player.getEyePosition();

        // Kameranın baktığı yön
        Vec3 direction =
                minecraft.gameRenderer.getMainCamera().getLookVector();

        // 30 blok ileri
        Vec3 end = start.add(direction.scale(30.0));

        float startX = (float) (start.x - cameraPos.x);
        float startY = (float) (start.y - cameraPos.y);
        float startZ = (float) (start.z - cameraPos.z);

        float endX = (float) (end.x - cameraPos.x);
        float endY = (float) (end.y - cameraPos.y);
        float endZ = (float) (end.z - cameraPos.z);

        Matrix4f matrix = poseStack.last().pose();

        // 🔴 Kırmızı lazer
        vertexConsumer
                .vertex(matrix, startX, startY, startZ)
                .color(1.0F, 0.0F, 0.0F, 1.0F)
                .normal(0.0F, 1.0F, 0.0F)
                .endVertex();

        vertexConsumer
                .vertex(matrix, endX, endY, endZ)
                .color(1.0F, 0.0F, 0.0F, 1.0F)
                .normal(0.0F, 1.0F, 0.0F)
                .endVertex();

        buffer.endBatch(RenderType.lines());
    }
}