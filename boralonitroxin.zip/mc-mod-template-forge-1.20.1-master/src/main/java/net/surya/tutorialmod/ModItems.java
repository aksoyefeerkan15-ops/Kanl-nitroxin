package net.surya.tutorialmod;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, TutorialMod.MOD_ID);

    public static final RegistryObject<Item> NITROXIN =
            ITEMS.register("nitroxin",
                    () -> new Item(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> KANLI_NITROXIN =
            ITEMS.register("kanli_nitroxin",
                    KanliNitroxinItem::new);

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }

    public static void addItemsToCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
            event.accept(NITROXIN);
            event.accept(KANLI_NITROXIN);
        }
    }
}