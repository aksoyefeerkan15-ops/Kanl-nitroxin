package net.surya.tutorialmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(
        modid = TutorialMod.MOD_ID,
        value = Dist.CLIENT
)
public class NitroxinClient {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {

        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null) {
            return;
        }

        // Kanlı Nitroxin gücü aktifse
        if (minecraft.player.hasEffect(
                net.minecraft.world.effect.MobEffects.DAMAGE_BOOST)) {

            // Kırmızı göz efekti burada aktif olacak.
            // Lazer ve enerji efektleri ayrı renderer dosyalarından geliyor.
        }
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {

        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.player == null) {
            return;
        }

        if (!minecraft.player.hasEffect(
                net.minecraft.world.effect.MobEffects.DAMAGE_BOOST)) {
            return;
        }

        // Kırmızı göz efekti için client tarafı kontrol.
    }
}