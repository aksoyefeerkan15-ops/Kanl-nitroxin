package net.surya.tutorialmod;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(
        modid = TutorialMod.MOD_ID,
        bus = Mod.EventBusSubscriber.Bus.MOD,
        value = net.minecraftforge.api.distmarker.Dist.CLIENT
)
public class NitroxinKey {

    public static final String KEY_CATEGORY =
            "key.categories." + TutorialMod.MOD_ID;

    public static final KeyMapping LASER_KEY = new KeyMapping(
            "key." + TutorialMod.MOD_ID + ".laser",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_L,
            KEY_CATEGORY
    );

    @SubscribeEvent
    public static void registerKey(RegisterKeyMappingsEvent event) {
        event.register(LASER_KEY);
    }
}